# -*- coding: utf-8 -*-
from odoo import api, fields, models, _, tools
from odoo.osv import expression
from odoo.exceptions import UserError, ValidationError
from joblib import dump, load
from sklearn_crfsuite import CRF
from sklearn_crfsuite import metrics
from datetime import datetime
import os
import subprocess
import random
import string

class Word (models.Model):

    _name = 'dictionary.word'
    _description = 'Word'

    def name_get(self):

        return [(record.id, record.word) for record in self]

    word= fields.Char ('Word',required=True)
    word_rules = fields.Char ('Word Rules')
    language_id= fields.Many2one ('language', 'Language', required=True)
    rule_ids= fields.Many2many  ('dictionary.rule', 'word_dictionary_rule_rel', 'word_id', 'rule_id', 'Rules')
    dictionary_id=fields.Many2one ('dictionary', 'Dictionary')
    word_flexion_ids=fields.One2many ('word.flexion', 'word_id', 'Flexions')
    word_affix_file=fields.Char ('Word affix file')
    word_dic_file=fields.Char ('Word dic file')
    affix_content = fields.Text("Affix Content")
    word_group_id = fields.Many2one('word.group','Group')
    def generate_word_affix_file(self):
        for rec in self:
            word_rules=""
            affix_content=""
            parent_rule=""
            for l in rec.rule_ids:
                affix_content=affix_content+l.type_id+" "+l.name+" "+"Y"+" "+"$$$$$"+"\n"
                word_rules=word_rules+l.name
                nb=0
                rule_line=""
                for rl in l.rule_line_ids:
                    if rl.pfx_rule_id.id:
                       parent_rule=parent_rule+rl.pfx_rule_id.type_id+" "+rl.pfx_rule_id.name+" "+"Y"+" "+"$$$$$"+"\n"
                       nb1=0
                       for rl1 in rl.pfx_rule_id.rule_line_ids:
                           nb1=nb1+1
                           parent_rule=parent_rule+rl.pfx_rule_id.type_id+" "+rl.pfx_rule_id.name+" "+str(rl1.regular_expression_prefix)+" "+str(rl1.regular_expression_suffix)+" "+str(rl1.substitution_chars)+"\n"
                       parent_rule=parent_rule.replace("$$$$$",str(nb1))+'\n'
                       #affix_content=affix_content+parent_rule
                    nb=nb+1
                    rule_line=rule_line+l.type_id+" "+l.name+" "+str(rl.regular_expression_prefix)+" "+str(rl.regular_expression_suffix)+" "+str(rl.substitution_chars)+"\n"
                affix_content=affix_content.replace("$$$$$",str(nb))+rule_line+'\n'
            rec.affix_content=affix_content
            rec.word_rules=word_rules
            alias = ''.join(random.choice(string.ascii_letters) for _ in range(50))
            aff=alias+'.aff'
            dic=alias+'.dic'
            if rec.word_affix_file:
               subprocess.getoutput("rm"+" ../../../../../home/odoo/kab/hunspell/"+rec.word_affix_file)
            if rec.word_dic_file:
               subprocess.getoutput("rm"+" ../../../../../home/odoo/kab/hunspell/"+rec.word_dic_file)
            rec.word_affix_file=aff
            rec.word_dic_file=dic

            af=open('../../../../../home/odoo/kab/hunspell/'+aff,"w+",encoding='utf-8')
            af.write("SET UTF-8 \n")
            af.write('("TRY abcdefghijklmnopqrstuvwxyzčǧḥɣṛṣṭɛẓABCDEFGHIJKLMNOPQRSTUVWXYZČǦḤƔṚṢṬƐẒ-") \n')
            af.write("CIRCUMFIX X \n")
            af.write(parent_rule)
            af.write(rec.affix_content)
            rec.affix_content="CIRCUMFIX X \n"+parent_rule+rec.affix_content
            af.close()
            dc=open('../../../../../home/odoo/kab/hunspell/'+dic,"w+",encoding='utf-8')
            dc.write('1\n')
            dc.write(rec.word+'/'+word_rules)
            dc.close()
            self.env['word.flexion'].search([('word_id', 'in', [rec.id])]).unlink()
            output= subprocess.getoutput("wordforms "+"../../../../../home/odoo/kab/hunspell/"+aff+" "+"../../../../../home/odoo/kab/hunspell/"+dic+" "+rec.word)
            for i in output.split("\n"):
             self.env['word.flexion'].create({'word':i,'word_id':rec.id,'language_id':rec.language_id.id})



        return True
    def generate_word_rules(self):

        word_rules=[i for i in self.word_rules]
        sql= """DELETE FROM word_dictionary_rule_rel WHERE word_id="""+str(self.id)
        self.env.cr.execute(sql)
        for rule in word_rules:
            rule_id= self.env['dictionary.rule'].search([('name','=',rule)])
            if (rule_id):
               sql = """ INSERT INTO word_dictionary_rule_rel (word_id, rule_id)  VALUES ("""+str(self.id)+""","""+str(rule_id.id)+""")"""
               self.env.cr.execute(sql)



        return True
    def form_word_rules(self):
        return True

    def generate_flexions(self):
        self.env['word.flexion'].search([('word_id', 'in', [self.id])]).unlink()

        output= subprocess.getoutput("wordforms ../../../../../home/odoo/kab/hunspell/kab.aff ../../../../..//home/odoo/kab/hunspell/kab.dic "+self.word)
        for i in output.split("\n"):
            self.env['word.flexion'].create({'word':i,'word_id':self.id,'language_id':self.language_id.id})
        return True

class WordGroup (models.Model):

    _name = 'word.group'
    _description = 'Word Group'

    name= fields.Char ('Group Name',required=True)
    language_id= fields.Many2one ('language', 'Language', required=True)
    code= fields.Char ('Group code')
    word_id= fields.One2many('dictionary.word','word_group_id','Words')
    rule_ids= fields.Many2many  ('dictionary.rule', 'word_group_rule_rel', 'group_id', 'rule_id', 'Rules')
    group_type = fields.Selection([('verbs','Verbs'),('names','Nouns/Adejtives')],'Group Type')
    def assign_rules_to_words(self):
        for rec in self:
            for word in rec.word_id:
                sql= """DELETE FROM word_dictionary_rule_rel WHERE word_id="""+str(word.id)
                self.env.cr.execute(sql)
                for rule in rec.rule_ids:

                    sql = """ INSERT INTO word_dictionary_rule_rel (word_id, rule_id)  VALUES ("""+str(word.id)+""","""+str(rule.id)+""")"""
                    self.env.cr.execute(sql)

                word.generate_word_affix_file()


class Flexion (models.Model):

    _name = 'word.flexion'
    _description = 'Word Flexion'

    def name_get(self):

        return [(record.id, record.word) for record in self]

    word= fields.Char ('Flexion',required=True)
    language_id= fields.Many2one ('language', 'Language', required=True)
    word_id= fields.Many2one  ('dictionary.word',  'Word')


class Rule (models.Model):

    _name = 'dictionary.rule'
    _description = 'Word Rules'

    name=fields.Char('Rule Name')
    type_id= fields.Selection ([('PFX', "Prefix"),('SFX', "Suffix")], 'Rule Type',default='prefix')
    rule_line_ids=fields.One2many ('dictionary.rule.line', 'rule_id', 'Rules Lines')
    circumfix = fields.Selection([("yes","Yes"),("no","No")],"Circumfix?")
    comment = fields.Char("Comment")
    word_group_ids = fields.Many2many ('word.group','rule_group','rule_id','word_group_id','Group')
class RuleLine (models.Model):

    _name = 'dictionary.rule.line'
    _description = 'Word Rules Line'

    pfx_rule_id = fields.Many2one ('dictionary.rule', 'Combined prefix rule')
    regular_expression_prefix = fields.Char('Affix condition')
    regular_expression_suffix = fields.Char('Affix to substitute')
    substitution_chars = fields.Char('Substitution chars')
    rule_id=fields.Many2one('dictionary.rule','Dictionary Rules')
    def name_get(self):

            return [(rec.id, rec.rule_id.name+ " " + rec.regular_expression_prefix + " "+ rec.regular_expression_suffix +" " +rec.substitution_chars) for rec in self]

class Dictionary (models.Model):
    _name = 'dictionary'
    _description = 'Dictionary'


    name= fields.Char('Dictionary name',translate=True)
    code= fields.Char('Dictionary code')
    description= fields.Html('Dictionary description',translate=True)
    language_id= fields.Many2one ('language', 'Language', required=True)
    word_ids = fields.Many2many  ('dictionary.word', 'word_dictionary_rel', 'dictionay_id', 'word_id', 'Words')
