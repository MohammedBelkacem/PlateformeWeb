import numpy as np

a=np.array([12,12])
print (a.ndim)
print (a.shape)