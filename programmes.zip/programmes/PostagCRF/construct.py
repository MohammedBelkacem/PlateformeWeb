﻿f= open("sentences_brut.txt","w+",encoding='utf-8')
g=open("corpus-kab.txt",encoding='utf-8')

for line in g:
    x=line.replace("  "," ").replace("\n","").split(" ")
    sent=""
    for i in x:
        y=i.split("/")
        sent=sent+" "+y[0]
    sent=sent.replace("- ",'-').replace(" -",'-')+"\n"
    f.write(sent)


f.close()
g.close()

