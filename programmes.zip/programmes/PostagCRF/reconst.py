h=open('corpus-kab.txt','r',encoding='utf-8')
g=open('corpuskab.txt','w+',encoding='utf-8')
for i in h:
    sentence=""

    j=i.split(' ')
    for k in j:
        l=k.split('/')
        sentence=sentence+l[0]+' '

    sentence=sentence.strip().replace('- ','-').replace(' -','-')
    g.write(sentence+'\n')

h.close()
g.close()