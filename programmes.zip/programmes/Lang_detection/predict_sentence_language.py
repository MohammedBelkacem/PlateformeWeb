## Ce programme permet de détecter la langue d'une phrase données en entrée d'une quanzaine de langues
##
##

from sklearn.preprocessing import LabelEncoder
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import CountVectorizer
from pickle import load

le = LabelEncoder()
le = load(open('label_model.pkl', 'rb'))

cv = CountVectorizer()
cv = load(open('model_cv.pkl', 'rb'))

model = MultinomialNB()
model = load(open('language_model.pkl', 'rb'))
def prediction(text,model,le):
    x = cv.transform([text]).toarray()
    lang = model.predict(x)
    lang = le.inverse_transform(lang)
    print("Tutlayt n tefyirt-a "+ text," d: ",lang[0])

prediction("Ass-a d ass amenzu",model,le)
prediction("Ad waliɣ ma yella yedda wahi. ",model,le)
prediction("Demain je travaille jusqu'à midi. ",model,le)