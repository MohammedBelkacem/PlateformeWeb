## Ce programme applique la segmentation morphosyntaxique de langue kabyle
##
uḍfiren=[]
uzwiren=[]

Asenqeḍ=['...',',',';','?','!',':','"','(',')','*','_','.','[',']','{','}','«','»','+','=','“','”']
for i in open("affixescolles.txt",encoding='utf-8'):
    a=i
    a=a.replace("\ufeff","")
    a=a.replace("\n","")
    if (a[len(a)-1]=="-"):

     uzwiren.append(str(a))
    else:
       uḍfiren.append(str(a))

def tokenize_awal(awal,uḍfiren,uzwiren):
    a=''
    amurfim=awal[0:awal.find('-')+1]

    awal_yebḍan=''
    if (amurfim in uzwiren):
        awal=awal[awal.find('-')+1:len(awal)]
        awal_yebḍan=awal_yebḍan+' '+amurfim
        while awal.find('-')>=0:

            amurfim=awal[0:awal.find('-')+1]
            awal=awal[awal.find('-')+1:len(awal)]
            awal_yebḍan=awal_yebḍan+' '+amurfim
        awal_yebḍan=awal_yebḍan+' '+awal
    else:
        amurfim=awal[0:awal.find('-')]
        awal_yebḍan=awal_yebḍan+' '+amurfim
        awal=awal[awal.find('-')+1:len(awal)]
        while awal.find('-')>=0:

           amurfim=awal[0:awal.find('-')]
           awal_yebḍan=awal_yebḍan+' '+'-'+amurfim
           awal=awal[awal.find('-')+1:len(awal)]
    if ('-'+awal in uḍfiren):
         awal_yebḍan=awal_yebḍan+' '+'-'+awal
    else:
         awal_yebḍan=awal_yebḍan



    return awal_yebḍan


def tokenize(sentence,uḍfiren,uzwiren):
       for i in Asenqeḍ:
        sentence=sentence.replace(i, " "+i+" ")
       a=sentence.split()
       tafyirt1=""
       for i in a: #mots
        if(i.find('-')<0):
            tafyirt1=tafyirt1+' '+i
        else:
            awals=tokenize_awal(i,uḍfiren,uzwiren)
            tafyirt1=tafyirt1+' '+awals
       tafyirt1=tafyirt1.strip()
       return tafyirt1





tifyar=[
'Ad as-tent-id-awiɣ.',
'Ay abrid ttun medden.',
'Yemɣi-d leḥcic di later-ik.',
'Aɛudiw n baba d jeddi, rniɣ rrekba n deffir!',
'Wwiɣ-d 4582 n tfunasin.',
'Axxam, ibennu ɣef llsas.',
'Llsas-nneɣ nekni d ayen nnan d wayen gan yimezwura-nneɣ.',
'D win i aɣ-ilaq ad d-nejmeɛ ass-a.',
'Awerrat iḥerzen ayen i as-d-yekkan sɣur lwaldin-is, yelha; win yernan s ayen i as-d-yeǧǧa baba-s, yif-it.',
'Win yebɣan, yettnadi amek; win yugin, yeqqar kan ulamek.',
'Am win yettnadin tilkin deg uqerru uferḍas.',
'Am win yettrebbin ibki, la taduṭ la ayefki.',
'Yal wa yettṣerrif seg wayen yesɛa.'

]
sentences=[]
for i in tifyar:
    tafyirt=tokenize(i,uḍfiren,uzwiren)
    tafyirt=tafyirt.split()
    print (tafyirt)
    sentences.append(tafyirt)

print (sentences)